import React from 'react'

export default function Footer() {
  return (
    <div>
        <footer className="footer">
              <div className="footer-div">
                <p>© 2023 - Iván Cano</p>
              </div>
            </footer>
    </div>
  )
}
