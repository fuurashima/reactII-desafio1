import { Container } from "react-bootstrap";

export default () => {
  return (
    <Container className="text-center">
      <h1 className="pt-5">
        Bienvenido a DESAFIO 1 🙌
      </h1>
      <br />
      
    </Container>
  );
};